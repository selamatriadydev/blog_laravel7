<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Post;
use App\User;
class Comment extends Model
{
    protected $fillable = [
        'username',
        'body',
        'user_id',
        'post_id',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($comment) {
            if (is_null($comment->user_id)) {
                $comment->user_id = auth()->user()->id;
            }
        });
    }

    public function post()
    {
        // return $this->belongsTo(Post::class);
        return $this->belongsTo('App\Post', 'post_id', 'id');
    }

    public function user()
    {
        // return $this->belongsTo(User::class);
        return $this->belongsTo('App\User', 'user_id', 'id');
    }
}
