<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Group extends Model
{
    protected $table = 'groups';
    protected $fillable = ['name','is_published'];

    public function groupData(){
        return $this->hasMany('App\GroupData', 'group_id', 'id');
    }
}
