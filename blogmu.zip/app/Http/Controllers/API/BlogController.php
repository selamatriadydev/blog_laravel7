<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Post;
use App\Http\Resources\BlogResource;
use App\Http\Resources\BlogDetailResource;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $posts = Post::when($request->search, function ($query) use ($request) {
            $search = $request->search;

            return $query->where('title', 'like', "%$search%")
                            ->orWhere('body', 'like', "%$search%");
        })->with('tags', 'category', 'user')
                    ->withCount('comments')
                    ->published()
                    ->simplePaginate(5);
        // return $posts;
        return BlogResource::collection($posts);
    }
    public function post($slug)
    {
        // $post = $post->load(['comments.user', 'tags', 'user', 'category']);
        $post = Post::with('tags', 'category', 'user')
                    ->where(['slug'=> $slug])
                    ->withCount('comments')
                    ->get();
        return BlogDetailResource::collection($post);
        // return $post;
    }

    public function comment(Request $request, Post $post)
    {
        $this->validate($request, ['body' => 'required']);

        $post->comments()->create([
            'body' => $request->body,
        ]);
        if($post){
            return ['success', 'Comment successfully created'];
        }
        return ['error', 'Comment failed created'];
    }
}
