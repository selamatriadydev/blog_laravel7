<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MenuData extends Model
{
    protected $table = 'menu_data';
    protected $fillable = ['group_id','menus_id'];

    public function group(){
        return $this->hasMany('App\GroupData', 'group_id', 'id');
    }
    public function menu(){
        return $this->hasMany('App\Menus', 'menus_id', 'id');
    }
}
