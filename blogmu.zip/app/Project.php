<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $fillable=['title', 'file_path', 'category_id', 'sort', 'is_published'];
    protected $table='project';

    public function category(){
        return $this->belongsTo('App\ProjectCategory', 'category_id', 'id');
    }
}
