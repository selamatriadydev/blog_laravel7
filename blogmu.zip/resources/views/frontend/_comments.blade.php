@forelse ($post->comments as $comment)
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">  
                <h4>{{ $comment->user->name }} says... </h4>
                <span class="pull-right">{{ $comment->created_at->diffForHumans() }}</span>
                </div>
                <div class="card-body">
                    <p>{{ $comment->body }}</p>
              </div>
            </div>
        </div>
      </div>
@empty
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">  
            <h4>Not Found!! </h4>
            </div>
            <div class="card-body">
                <p>Sorry! No comment found for this post.</p>
          </div>
        </div>
    </div>
  </div>
@endforelse
