<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <form action="#" method="get" role="form" >
                    @csrf
                    <input type="text" name="search" class="form-control">
                </form>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">
                Cari
            </button>
          </div>
        </div>
    </div>
  </div>