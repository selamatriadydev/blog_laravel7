@extends('layouts.frontend')

@section('title', 'Blog')

@section('navbar')
    @include('frontend/components/navbar')
@endsection

@section('page_title', ' Blog') 

@section('content')
<form action="{{ url('/admin/tags') }}" method="post" enctype="multipart/form-data">
  @csrf
  @forelse ($posts as $post)
  <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header">  
            <h4>{{ $post->title }} - <small>by {{ $post->user->name }}</small></h4>
              <span class="pull-right">
                {{ $post->created_at->toDayDateTimeString() }}
                </span>
            </div>
              <div class="card-body">
                <p>{{ Str::limit($post->body, 200) }}</p>
            </div>
            <div class="card-footer text-right">
                <p>
                    Tags:
                    @forelse ($post->tags as $tag)
                        <span class="label label-default">{{ $tag->name }}</span>
                    @empty
                        <span class="label label-danger">No tag found.</span>
                    @endforelse
                </p>
                <p>
                    <span class="btn btn-sm btn-success">{{ $post->category->name }}</span>
                    <span class="btn btn-sm btn-info">Comments <span class="badge">{{ $post->comments_count }}</span></span>

                    <a href="{{ url("/posts/{$post->id}") }}" class="btn btn-sm btn-primary">See more</a>
                </p>
            </div>
          </div>
      </div>
    </div>
  @empty
  <div class="row">
    <div class="col-md-12">
        <div class="card">
            <h2>Not Found!!</h2>
            <div class="card-body">
                <p>Sorry! No post found.</p>
          </div>
        </div>
    </div>
  </div>
  @endforelse
  {!! $posts->appends(['search' => request()->get('search')])->links() !!}
</form>


@endsection