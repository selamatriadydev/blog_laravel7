<div class="form-group<?php echo e($errors->has('skill_id') ? ' is-invalid' : ''); ?> ">
    <label>Skill</label>
    <select name="skill_id" id="skill_id" class="form-control" required>
        <option value="">pilih Parent</option>
        <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($par && $par->skill_id==$item->id ? 'selected=""': ''); ?>> <?php echo e($item->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($errors->has('skill_id')): ?>
      <span class="help-block">
        <strong class="text-danger"><?php echo e($errors->first('skill_id')); ?></strong>
      </span>
    <?php endif; ?>
</div>
<div class="form-group<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>">
    <label>Title</label>
    <input type="text" class="form-control" name="title" id="txtSkills" value="<?php echo e($par && $par->title ? $par->title : ''); ?>" required>
    <?php if($errors->has('title')): ?>
      <span class="help-block">
        <strong class="text-danger"><?php echo e($errors->first('title')); ?></strong>
      </span>
    <?php endif; ?>
</div>
<div class="form-group<?php echo e($errors->has('sort') ? '  is-invalid' : ''); ?>">
    <label>Sort</label>
    <input type="text" class="form-control" name="sort" id="txtSkills" value="<?php echo e($par && $par->sort ? $par->sort : ''); ?>">
    <?php if($errors->has('sort')): ?>
      <span class="help-block">
        <strong><?php echo e($errors->first('sort')); ?></strong>
      </span>
    <?php endif; ?>
</div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/skillDetail/_form.blade.php ENDPATH**/ ?>