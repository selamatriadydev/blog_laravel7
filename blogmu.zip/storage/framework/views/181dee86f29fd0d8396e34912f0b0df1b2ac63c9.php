<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('frontend/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', ' Blog'); ?> 

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/admin/tags')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header">  
            <h4><?php echo e($post->title); ?> - <small>by <?php echo e($post->user->name); ?></small></h4>
              <span class="pull-right">
                <?php echo e($post->created_at->toDayDateTimeString()); ?>

                </span>
            </div>
              <div class="card-body">
                <p><?php echo e(Str::limit($post->body, 200)); ?></p>
            </div>
            <div class="card-footer text-right">
                <p>
                    Tags:
                    <?php $__empty_2 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <span class="label label-default"><?php echo e($tag->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <span class="label label-danger">No tag found.</span>
                    <?php endif; ?>
                </p>
                <p>
                    <span class="btn btn-sm btn-success"><?php echo e($post->category->name); ?></span>
                    <span class="btn btn-sm btn-info">Comments <span class="badge"><?php echo e($post->comments_count); ?></span></span>

                    <a href="<?php echo e(url("/posts/{$post->id}")); ?>" class="btn btn-sm btn-primary">See more</a>
                </p>
            </div>
          </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <div class="row">
    <div class="col-md-12">
        <div class="card">
            <h2>Not Found!!</h2>
            <div class="card-body">
                <p>Sorry! No post found.</p>
          </div>
        </div>
    </div>
  </div>
  <?php endif; ?>
  <?php echo $posts->appends(['search' => request()->get('search')])->links(); ?>

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/projectme/blogmu/resources/views/frontend/list.blade.php ENDPATH**/ ?>