<?php $__env->startSection('title', 'Skill'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin/components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'List Sub Skill '.$skill->title); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <a href="<?php echo e(url('admin/skill')); ?>" class="btn btn-primary"> <i class="fa fa-eye"></i>Back</a>
            </div>
            <div class="card-body"> 
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Skill</th>
                    <th scope="col">Publish</th>
                    <th scope="col">Sort</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $skillDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?> </th>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e($post->is_published ? 'YES': 'NO'); ?></td>
                            <td><?php echo e($post->sort); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No post available.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
            <div class="card-footer">
                <?php echo $skillDetail->links(); ?>

            </div>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/skill/show.blade.php ENDPATH**/ ?>