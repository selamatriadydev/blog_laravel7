<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
    <label>Menu</label>
    <input type="text" class="form-control" name="title" id="txtSkills" value="<?php echo e($menus && $menus->title ? $menus->title : ''); ?>">
    <span class="help-block">
        <strong><?php echo e($errors->first('title')); ?></strong>
    </span>
</div>
<div class="form-group<?php echo e($errors->has('link') ? ' has-error' : ''); ?>">
    <label>Link</label>
    <input type="text" class="form-control" name="link" id="txtSkills" value="<?php echo e($menus && $menus->link ? $menus->link : '#'); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('link')); ?></strong>
    </span>
</div>
<div class="form-group<?php echo e($errors->has('parent_id') ? ' has-error' : ''); ?>">
    <label>Parent</label>
    <select name="parent_id" id="parent_id" class="form-control">
        <option value="0">pilih Parent</option>
        <?php $__currentLoopData = $parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($menus && $menus->parent_id==$item->id ? 'selected=""': ''); ?>> <?php echo e($item->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <span class="help-block">
      <strong><?php echo e($errors->first('parent_id')); ?></strong>
    </span>
</div>
<div class="form-group<?php echo e($errors->has('sort') ? ' has-error' : ''); ?>">
    <label>Sort</label>
    <input type="text" class="form-control" name="sort" id="txtSkills" value="<?php echo e($menus && $menus->sort ? $menus->sort : '0'); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('sort')); ?></strong>
    </span>
</div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/menus/_form.blade.php ENDPATH**/ ?>