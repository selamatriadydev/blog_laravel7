<?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">  
                <h4><?php echo e($comment->user->name); ?> says... </h4>
                <span class="pull-right"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                </div>
                <div class="card-body">
                    <p><?php echo e($comment->body); ?></p>
              </div>
            </div>
        </div>
      </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">  
            <h4>Not Found!! </h4>
            </div>
            <div class="card-body">
                <p>Sorry! No comment found for this post.</p>
          </div>
        </div>
    </div>
  </div>
<?php endif; ?>
<?php /**PATH /var/www/html/projectme/blogmu/resources/views/frontend/_comments.blade.php ENDPATH**/ ?>