<?php $__env->startSection('title', 'Group'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin/components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'List Group'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <a href="<?php echo e(url('admin/group/create')); ?>" class="btn btn-primary"> <i class="fa fa-plus"></i>Add</a>
            </div>
            <div class="card-body"> 
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Group</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?> </th>
                            <td><?php echo e($post->name); ?></td>
                            <td>
                            <a href="<?php echo e(url("/admin/group/{$post->id}/edit")); ?>" class="btn btn-xs btn-info"><i class="fa fa-pen"></i></a>
                            <form method="POST" action="<?php echo e(url("admin/group/{$post->id}")); ?>" class="form-inline d-inline" onsubmit="return confirm('Are you sure you want to delete this item?')">
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field("DELETE"); ?>
                                <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm" data-toggle="tooltip" title='Delete' > <i class="fa fa-trash"> </i></button>
                            </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No post available.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
            <div class="card-footer">
                <?php echo $group->links(); ?>

            </div>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/group/list.blade.php ENDPATH**/ ?>