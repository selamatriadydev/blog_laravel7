<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('frontend/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Info Blog'); ?> 

<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header">  
              <h4><?php echo e($post->title); ?> - <small>by <?php echo e($post->user->name); ?></small></h4>
              <span class="pull-right">
                <?php echo e($post->created_at->toDayDateTimeString()); ?>

                </span>
            </div>
              <div class="card-body">
                <p><?php echo e($post->body); ?></p>
            </div>
            <div class="card-footer">
                <p>
                    Tags:
                    <?php $__empty_1 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <span class="label label-default"><?php echo e($tag->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="label label-danger">No tag found.</span>
                    <?php endif; ?>
                </p>
                <p>
                    <span class="btn btn-sm btn-success"><?php echo e($post->category->name); ?></span>
                </p>
            </div>
          </div>
      </div>
    </div>
    <?php echo $__env->renderWhen(Auth::user(), 'frontend._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
    <?php echo $__env->make('frontend._comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/projectme/blogmu/resources/views/frontend/post.blade.php ENDPATH**/ ?>