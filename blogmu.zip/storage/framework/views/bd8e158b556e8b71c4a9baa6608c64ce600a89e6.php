<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
    <label>Title</label>
    <input type="text" class="form-control" name="title" id="txtSkills" value="<?php echo e($banner && $banner->title ? $banner->title : ''); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('title')); ?></strong>
    </span>
</div>
<div class="form-group<?php echo e($errors->has('body') ? ' has-error' : ''); ?>">
    <label>Body</label>
    <input type="text" class="form-control" name="body" id="txtSkills" value="<?php echo e($banner && $banner->body ? $banner->body : ''); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('body')); ?></strong>
    </span>
</div>
<div class="form-group<?php echo e($errors->has('sort') ? ' has-error' : ''); ?>">
    <label>Sort</label>
    <input type="text" class="form-control" name="sort" id="txtSkills" value="<?php echo e($banner && $banner->sort ? $banner->sort : ''); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('sort')); ?></strong>
    </span>
</div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/banner/_form.blade.php ENDPATH**/ ?>