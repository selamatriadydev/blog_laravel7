<?php $__env->startSection('title', 'Post'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin/components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Show Post'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
              <b><?php echo e($post->title); ?></b>
              <p><?php echo e($post->body); ?></p>
              <p><strong>Category: </strong><?php echo e($post->category->name); ?></p>
            <p><strong>Tags: </strong><?php echo e($post->tags->implode('name', ', ')); ?></p>
            <p><strong>Publish: </strong><?php echo e($post->is_published ? 'Publish' : 'Draft'); ?></p>
          </div>
          <div class="card-footer text-right">
            <a href="<?php echo e(url('admin/posts')); ?>" class="btn btn-danger mr-1">Back</a>
          </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/post/show.blade.php ENDPATH**/ ?>