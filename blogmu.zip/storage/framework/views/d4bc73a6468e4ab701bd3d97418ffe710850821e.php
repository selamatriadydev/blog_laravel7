<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">  
            <h4>Write Comment </h4>
            </div>
            <form action="<?php echo e(url("posts/{$post->id}/comment")); ?>" method="post" >
            <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <textarea name="body" id="" rows="3" class="form-control"></textarea>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">
                        Reply
                    </button>
                </div>
            </form>
        </div>
    </div>
  </div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/frontend/_form.blade.php ENDPATH**/ ?>