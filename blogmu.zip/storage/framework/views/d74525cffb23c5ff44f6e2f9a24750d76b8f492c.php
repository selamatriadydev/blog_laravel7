<div class="form-group<?php echo e($errors->has('tags') ? ' has-error' : ''); ?>">
    <label>Name</label>
    <input type="text" class="form-control" name="tags" id="txtSkills" value="<?php echo e($tag && $tag->name ? $tag->name : ''); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('tags')); ?></strong>
    </span>
  </div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/tags/_form.blade.php ENDPATH**/ ?>