<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
    <label>Title</label>
    <input type="text" class="form-control" name="title" id="txtSkills" value="<?php echo e($par && $par->title ? $par->title : ''); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('title')); ?></strong>
    </span>
</div>
<div class="form-group<?php echo e($errors->has('sort') ? ' has-error' : ''); ?>">
    <label>Sort</label>
    <input type="text" class="form-control" name="sort" id="txtSkills" value="<?php echo e($par && $par->sort ? $par->sort : ''); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('sort')); ?></strong>
    </span>
</div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/skill/_form.blade.php ENDPATH**/ ?>