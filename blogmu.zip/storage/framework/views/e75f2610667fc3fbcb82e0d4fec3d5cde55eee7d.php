<div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
    <label>Name</label>
    <input type="text" class="form-control" name="category" id="txtSkills" value="<?php echo e($category && $category->name ? $category->name : ''); ?>">
    <span class="help-block">
      <strong><?php echo e($errors->first('category')); ?></strong>
    </span>
  </div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/category/_form.blade.php ENDPATH**/ ?>