<div class="main-sidebar">
    <aside id="sidebar-wrapper">
      <div class="sidebar-brand">
        <a href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'BlogMu')); ?></a>
      </div>
      <div class="sidebar-brand sidebar-brand-sm">
        <a href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'BM')); ?></a>
      </div>
      <ul class="sidebar-menu">
          
          
          <?php $__currentLoopData = App\Menus::orderBy('sort','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           

            <?php if( $menuItem->parent_id == 0 ): ?>
             
              <li <?php echo e($menuItem->link ? '' : "class=nav-item dropdown"); ?> class="<?php echo e((request()->is($menuItem->link.'*')) ? 'active' : ''); ?>">
              <a href="<?php echo e($menuItem->children->isEmpty() ? url($menuItem->link) : "#"); ?>"
                class="nav-link <?php echo e($menuItem->children->isEmpty() ? '' : 'has-dropdown'); ?>"
                data-toggle="<?php echo e($menuItem->children->isEmpty() ? '' : 'dropdown'); ?>">
                  <i class="fas fa-columns"></i> 
                  <span><?php echo e($menuItem->title); ?></span>
              </a>
            <?php endif; ?>

            <?php if( ! $menuItem->children->isEmpty() ): ?>
              <ul class="dropdown-menu">
                <?php $__currentLoopData = $menuItem->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a class="nav-link <?php echo e((request()->is($subMenuItem->link.'*')) ? 'active' : ''); ?>" href="<?php echo e(url($subMenuItem->link)); ?>"><?php echo e($subMenuItem->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </aside>
  </div><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/components/sidebar.blade.php ENDPATH**/ ?>