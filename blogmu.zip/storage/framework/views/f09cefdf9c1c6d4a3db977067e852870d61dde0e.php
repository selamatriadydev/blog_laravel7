<?php $__env->startSection('title', 'Banner'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin/components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'New Banner'); ?> 

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/admin/banner')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
              <?php echo $__env->make('admin.banner._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
          <div class="card-footer text-right">
            <button class="btn btn-primary mr-1" type="submit">Save</button>
            <button class="btn btn-danger mr-2" type="reset">Reset</button>
            <a href="<?php echo e(url('admin/banner')); ?>" class="btn btn-danger mr-1">Back</a>
          </div>
        </div>
    </div>
  </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/banner/add.blade.php ENDPATH**/ ?>