<?php $__env->startSection('title', 'Post'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin/components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'New Post'); ?> 

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/admin/posts')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
              <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                <input type="text" class="form-control" placeholder="Masukan Judul" name="title" required autofocus>
                  <span class="help-block">
                    <strong><?php echo e($errors->first('title')); ?></strong>
                  </span>
              </div>
          </div>
          <div class="card-footer text-right">
            <button class="btn btn-primary mr-1" type="submit">Save</button>
            <button class="btn btn-danger mr-2" type="reset">Reset</button>
            <a href="<?php echo e(url('admin/posts')); ?>" class="btn btn-danger mr-1">Back</a>
          </div>
        </div>
    </div>
    <div class="col-12 col-md-9 col-lg-9">
        <div class="card">
            <div class="card-body">
              <div class="form-group<?php echo e($errors->has('body') ? ' has-error' : ''); ?>">
                <textarea class="form-control" name="body"></textarea>
                <span class="help-block">
                  <strong><?php echo e($errors->first('body')); ?></strong>
                </span>
              </div>
          </div>
        </div>
    </div>
    <div class="col-12 col-md-3 col-lg-3">
        <div class="card">
            <div class="card-body">
              <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                <label>Gambar</label>
                <input type="file" class="form-control" name="image">
                <span class="help-block">
                  <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
              </div>
              <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                <label>Category</label>
                <select class="form-control" data-height="100%" style="height: 100%;" name="category">
                  <option value="">Pilih </option>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="help-block">
                  <strong><?php echo e($errors->first('category')); ?></strong>
                </span>
              </div>
              <div class="form-group<?php echo e($errors->has('tag') ? ' has-error' : ''); ?>">
                <label>Tag</label>
                <input type="text" class="form-control" name="tags[]" id="txtSkills" data-role="tagsinput" multiple>
                <span class="help-block">
                  <strong><?php echo e($errors->first('tag')); ?></strong>
                </span>
              </div>
              <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                <label>Status</label>
                <select class="form-control" data-height="100%" style="height: 100%;" name="status">
                  <option value="1">Publish</option>
                  <option value="0">Draft</option>
                </select>
                <span class="help-block">
                  <strong><?php echo e($errors->first('status')); ?></strong>
                </span>
              </div>
          </div>
        </div>
    </div>
  </div>
</form>

<script>
  $('#txtSkills').tagsinput({
	  itemValue : 'id',
	  itemText  : 'name',
	  maxChars: 10,
	  trimValue: true,
	  allowDuplicates : false,
	  freeInput: false,
	  focusClass: 'form-control',
	  tagClass: function(item) {
		  if(item.display)
		 	 return 'label label-' + item.display;
		  else
			  return 'label label-default';

	  },
	  onTagExists: function(item, $tag) {
		  $tag.hide().fadeIn();
	  },
	  typeaheadjs: [{
		  		hint: false,
	                	highlight: true
	                },
	                {
		    	       name: 'skills',
		    		itemValue: 'id',
		    		displayKey: 'name',
		    		source: skills.ttAdapter(),
		    		templates: {
		                empty: [
		                    '<ul class="list-group"><li class="list-group-item">Nothing found.</li></ul>'
		                ],
		                header: [
		                    '<ul class="list-group">'
		                ],
		                suggestion: function (data) {
		                    return '<li class="list-group-item">' + data.name + '</li>'
		          		}
		    		}
		}]
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/projectme/blogmu/resources/views/admin/post/add.blade.php ENDPATH**/ ?>